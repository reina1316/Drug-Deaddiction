const apiKey = "AIzaSyBQoMuYm9wiKCr-Cf3LBTQDbRY1AkSzu4I"; // ⚠️ Your API key (EXPOSED, be careful)
const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;

document.addEventListener("DOMContentLoaded", function () {
    const chatBox = document.getElementById("chat-box");
    const userInput = document.getElementById("user-input");
    const sendButton = document.getElementById("send-button");

    if (!chatBox || !userInput || !sendButton) {
        console.error("One or more elements not found. Check your HTML IDs.");
        return;
    }

    sendButton.onclick = function () {
        const message = userInput.value.trim();
        if (message) {
            addMessage("You: " + message);
            userInput.value = "";
            getChatbotResponse(message);
        }
    };
});

// Function to add messages to the chat box
function addMessage(message) {
    const chatBox = document.getElementById("chat-box");
    const messageElement = document.createElement("p");
    messageElement.textContent = message;
    chatBox.appendChild(messageElement);
    chatBox.scrollTop = chatBox.scrollHeight; // Auto-scroll
}

// Function to get chatbot response from Google Gemini API
function getChatbotResponse(message) {
    fetch(apiUrl, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            contents: [
                {
                    role: "user",
                    parts: [{ 
                        text: `You are a supportive and empathetic chatbot designed to assist individuals struggling with addiction. Your primary goals are to provide encouragement, share resources, and create a safe, non-judgmental space for users to express their feelings. 

1. Always acknowledge and validate users' feelings.
2. Encourage users to share their progress and celebrate their achievements.
3. Provide information about local support groups and recovery resources.
4. Offer healthy coping strategies for cravings and stress.
5. Ask open-ended questions to promote dialogue and reflection.
6. Prioritize user safety and well-being, especially in crisis situations.
7. Incorporate light humor when appropriate, while remaining respectful.
8. Regularly seek feedback to improve the chatbot's functionality and support.`
                    }]
                }
            ]
        })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("API Error: " + response.statusText);
        }
        return response.json();
    })
    .then(data => {
        console.log("API Response:", data);

        if (data.candidates && data.candidates.length > 0) {
            const botReply = data.candidates[0]?.content?.parts?.[0]?.text || "I don't know how to respond.";
            addMessage("Chatbot: " + botReply);
        } else {
            addMessage("Chatbot: Sorry, I didn't understand that.");
        }
    })
    .catch(error => {
        console.error("Error:", error);
        addMessage("Chatbot: Sorry, I couldn't process your request.");
    });
}